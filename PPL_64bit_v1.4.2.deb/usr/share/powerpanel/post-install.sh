#!/bin/sh

#
# The PowerPanel for Linux Software Post-installation
#

DAEMON="pwrstatd"
MATCH_OS=0
VAR=`echo $PATH | grep /usr/sbin`
MATCH_RC_PATH=0
RC_DIR=""
START_LN=""
STOP_LN=""
STRATUP_DIR="/usr/sbin"

if [ ${#VAR} = 0 ]; then
	export PATH=$PATH:/usr/sbin
fi

# register to system for startup at system booting
if [ $MATCH_OS = 1 ] && [ -e /sbin/chkconfig ] || [ -e /usr/sbin/sysvconfig ]; then
	if [ -e /sbin/chkconfig ]; then
		/sbin/chkconfig --add $DAEMON
		/sbin/chkconfig --level 2345 $DAEMON on    
	fi
fi

#
# Restore config file when update PowerPanel software
#

# Script command for event of power failure 
if [ -e /etc/pwrstatd-powerfail-backup.sh ]; then    
	/bin/mv /etc/pwrstatd-powerfail-backup.sh /etc/pwrstatd-powerfail.sh
fi

# Script command for event of battery low 
if [ -e /etc/pwrstatd-lowbatt-backup.sh ]; then    
	/bin/mv /etc/pwrstatd-lowbatt-backup.sh /etc/pwrstatd-lowbatt.sh
fi

# Script command for e-mail notification
if [ -e /etc/pwrstatd-email-backup.sh ]; then
	/bin/mv /etc/pwrstatd-email-backup.sh /etc/pwrstatd-email.sh
fi

# Script command for execution shutdown when power event occur
if [ -e /etc/shutdown-backup.sh ]; then
	/bin/mv /etc/shutdown-backup.sh /etc/shutdown.sh
fi

# Script command for execution hibernate when power event occur
if [ -e /etc/hibernate-backup.sh ]; then
	/bin/mv /etc/hibernate-backup.sh /etc/hibernate.sh
fi

# PowerPanel for Linux daemon configuration
if [ -e /etc/pwrstatd-backup.conf ]; then   
	/bin/mv /etc/pwrstatd-backup.conf /etc/pwrstatd.conf
fi

# systemd
if [ -e /bin/systemctl ]; then
	/bin/systemctl daemon-reload
	/bin/systemctl enable $DAEMON.service
fi

# startup daemon immediately
if [ -e $STRATUP_DIR/$DAEMON ]; then
	/bin/systemctl start $DAEMON
fi

# Notice a message 
if [ $MATCH_RC_PATH = 0 ]; then
	/bin/echo "Installation accomplish!"
else
	/bin/echo "Fail to setup daemon startup script when system booting!"
fi

echo

