#!/bin/sh

#
# The PowerPanel for Linux Software Uninstallation
#

DAEMON="pwrstatd" 
MATCH_OS=0
RC_DIR=""
START_LN=""
STOP_LN=""

# uppercase to lowercase and search keyword string
OS=`cat /proc/version | grep -i 'suse'`
if [ ${#OS} != 0 ]; then
	MATCH_OS=1
fi

OS=`cat /proc/version | grep -i 'red hat'`
if [ ${#OS} != 0 ]; then
	MATCH_OS=1
fi

OS=`cat /proc/version | grep -i 'ubuntu'`
if [ ${#OS} != 0 ]; then
	MATCH_OS=1
fi

OS=`cat /proc/version | grep -i 'debian'`
if [ ${#OS} != 0 ]; then
	MATCH_OS=1
fi

OS=`cat /etc/os-release | grep -i 'raspbian'`
if [ ${#OS} != 0 ]; then
	MATCH_OS=1
fi

# have not match any linux OS

# Remove pwrstatd startup registry

if [ $MATCH_OS = 1 ]; then
	if [ -e /sbin/chkconfig ]; then
	    /sbin/chkconfig --level 2345 $DAEMON off
	    /sbin/chkconfig --del $DAEMON       
	fi
fi

# Stop the pwrstatd process
if [ -e /usr/sbin/$DAEMON ]; then 
	/bin/systemctl stop $DAEMON
fi


# Terminate pwrstatd process forcedly!
CMD=`ps -A | grep pwrstatd`
if [ ${#CMD} != 0 ]; then
	if [ -e /sbin/killproc ]; then
		/sbin/killproc -TERM /usr/sbin/$DAEMON
	else
		set -- $CMD    # set result as varable $1 ~ $9(max)		
		kill -TERM $1	# $1 denote process ID(PID)
	fi		
fi

#
# remove files
#

# daemon log file
if [ -e /var/log/pwrstatd.log ]; then
 	/bin/rm /var/log/pwrstatd.log
fi

# daemon device path file
if [ -e /var/pwrstatd.dev ]; then
 	/bin/rm /var/pwrstatd.dev
fi

# daemon ipc file
if [ -e /var/pwrstatd.ipc ]; then
 	/bin/rm /var/pwrstatd.ipc
fi

# systemd
if [ -e /etc/systemd/system/pwrstatd.service ]; then
	/bin/rm /etc/systemd/system/pwrstatd.service
fi
if [ -e /bin/systemctl ]; then
	/bin/systemctl daemon-reload
fi

# mqtt cert
if [ -e /etc/pwrstatd.cacrt ]; then
	/bin/rm /etc/pwrstatd.cacrt
fi
if [ -e /etc/pwrstatd.ccrt ]; then
	/bin/rm /etc/pwrstatd.ccrt
fi
if [ -e /etc/pwrstatd.ckey ]; then
	/bin/rm /etc/pwrstatd.ckey
fi

# daemon properties file
if [ -e /etc/pwrstatd.properties ]; then
	/bin/rm /etc/pwrstatd.properties
fi

# ca cert
if [ -e /etc/cacert.pem ]; then
	/bin/rm /etc/cacert.pem
fi

# shared libraries
if [ -e /usr/local/lib/powerpanel ]; then
	/bin/rm -rf /usr/local/lib/powerpanel
fi

# website password
if [ -e /etc/pwrstatd.pwd ]; then
	/bin/rm /etc/pwrstatd.pwd
fi

# Notice a message
/bin/echo "uninstallation accomplish!"
