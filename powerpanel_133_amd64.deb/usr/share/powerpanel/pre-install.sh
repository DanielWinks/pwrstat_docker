#!/bin/sh

#
# The PowerPanel for Linux Software Pre-installation
#

DAEMON="pwrstatd"
VAR=`echo $PATH | grep /usr/sbin`

if [ ${#VAR} = 0 ]; then
	export PATH=$PATH:/usr/sbin
fi

# Remove pwrstatd startup registry
if [ -e /etc/init.d/$DAEMON ]; then

        if [ -e /sbin/chkconfig ]; then
               /sbin/chkconfig --level 2345 $DAEMON off
               /sbin/chkconfig --del $DAEMON
        else 
        	  # for ubuntu/debian linux
	        if [ -e /usr/sbin/sysvconfig ]; then
	        		/usr/sbin/sysvconfig --disable $DAEMON	        
	        fi          
        fi
        
        # stop pwrstatd process
        /etc/init.d/pwrstatd stop
fi

# Terminate pwrstatd process forcedly!
CMD=`ps -A | grep $DAEMON`
if [ ${#CMD} != 0 ]; then		#string length

	if [ -e /sbin/killproc ]; then
		/sbin/killproc -TERM /usr/sbin/$DAEMON
	else
		set -- $CMD     # set result as varable $1 ~ $9(max)		
		kill -TERM $1	# $1 denote process ID(PID)
	fi

fi

#
# store config file when update PowerPanel software
#

# Script command for event of power failure 
if [ -e /etc/pwrstatd-powerfail.sh ]; then    
	/bin/mv /etc/pwrstatd-powerfail.sh /etc/pwrstatd-powerfail-backup.sh
fi

# Script command for event of battery low 
if [ -e /etc/pwrstatd-lowbatt.sh ]; then    
	/bin/mv /etc/pwrstatd-lowbatt.sh /etc/pwrstatd-lowbatt-backup.sh
fi

# Script command for e-mail notification
if [ -e /etc/pwrstatd-email.sh ]; then
	/bin/mv /etc/pwrstatd-email.sh /etc/pwrstatd-email-backup.sh
fi

# Script command for execution shutdown when power event occur
if [ -e /etc/shutdown.sh ]; then
	/bin/mv /etc/shutdown.sh /etc/shutdown-backup.sh
fi

# Script command for execution hibernate when power event occur
if [ -e /etc/hibernate.sh ]; then
	/bin/mv /etc/hibernate.sh /etc/hibernate-backup.sh
fi

# PowerPanel for Linux daemon configuration
if [ -e /etc/pwrstatd.conf ]; then   
	/bin/mv /etc/pwrstatd.conf /etc/pwrstatd-backup.conf
fi

echo

